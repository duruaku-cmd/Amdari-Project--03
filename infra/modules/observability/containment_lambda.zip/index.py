import json

def handler(event, context):
    """
    Receives a high-severity GuardDuty finding via EventBridge and performs
    a containment action. Day 12 logs the finding and the intended action;
    Week 3's attack simulation exercises the real containment path.
    """
    detail = event.get("detail", {})
    finding_type = detail.get("type", "unknown")
    severity = detail.get("severity", "unknown")
    print(f"[CONTAINMENT] High-severity GuardDuty finding received: "
          f"type={finding_type} severity={severity}")
    print(f"[CONTAINMENT] Full finding: {json.dumps(detail)[:1000]}")
    # Week 3: isolate the affected resource / disable the implicated key here.
    return {"status": "received", "type": finding_type, "severity": severity}
